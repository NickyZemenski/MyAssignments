﻿using System;

namespace InClass5
{
    class Program
    {
        static void Main(string[] args)
        {


            
            Console.WriteLine("Please enter names you would like to scramble");

            string[] namesArr = Console.ReadLine().Split(" ");


            string scrambledName = "";


            for(int i = namesArr.Length - 1; i >= 0; i--)    // this loop takes the names one by one from the array
            {

                string partialName = namesArr[i];
                for(int j = partialName.Length - 1; j >= 0; j--)  // this loop takes the string of one name and scrambles it backwards 
                {
                    scrambledName += partialName[j];
                }
                scrambledName += " ";
            }


            Console.WriteLine("Your scrambled name is");   // wasnt sure if I should add only the name or not so I added this line to make sure I had it if needed and to not disrupt the scambled name ... if needed the two lines could be on the same line as well

            Console.WriteLine(scrambledName);




    





            Console.WriteLine("Please enter card number to have its digit checked");


            string cardNumber = Console.ReadLine(); //I choose to work with strings as they dont have a restriction to length while 32 bit integers have a limit of 2,147,483,647 ... I could work with long integers but again as there doesnt seem to be a need to waste compile time on it I choose strings

            string workedCardNumber ="";
            
            for(int i = 0; i < cardNumber.Length; i++)
            {
                if (i % 2 == 0)
                {
                    int currentNumber = (cardNumber[i]-'0') * 2;  // im using the ascii table to convert the char number to an actual number I could use ... the other option would be to use a toString then parse to int 

                    workedCardNumber += currentNumber.ToString();

                }

                else
                {
                    workedCardNumber += "" + cardNumber[i];
                }
            }



            int addedNumbers = 0;

            for (int i = 0; i < workedCardNumber.Length; i++)
            {
                addedNumbers += (workedCardNumber[i] - '0');



            }


            int checkDigit = 10 - (addedNumbers % 10);

            if (checkDigit == 10)
            {
                checkDigit = 0;
            }

            Console.WriteLine("Your cards digit is:" + checkDigit);
        }
    }
}
