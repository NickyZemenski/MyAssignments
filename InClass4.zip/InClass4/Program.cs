﻿using System;
using System.ComponentModel;

namespace InClass4
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("How many items are on todays menu?");



            int numOfItemsForSale = 0;
            while (true)
            {
                try
                {

                    numOfItemsForSale = int.Parse(Console.ReadLine());
                    if (numOfItemsForSale <= 0)
                    {
                        Console.WriteLine("You can not open with negative or 0 dishes please try again");
                    }


                    else
                    {

                        break;
                    }
                }
                catch
                {
                    Console.WriteLine("Please enter a number");
                }
            }

            Console.WriteLine("Please create your menu for the day");

            string[] namesOfDishes = new string[numOfItemsForSale];





            for (int i = 0; i < namesOfDishes.Length; i++)
            {
                int displayNumber = i + 1;
                Console.Write("Enter the dish number " + displayNumber + ": ");
                namesOfDishes[i] = Console.ReadLine();
            }



            while (true)
            {

                Console.WriteLine("How much is your budget?");
                double budget = double.Parse(Console.ReadLine());               //we can use a try catch and so on or make the loop on line  16 to 38 a method to parse numbers but as the essence is shown above I shall refrain from doing so again. 



                Console.WriteLine("What would you like to purchase from these items? Please enter the number.");

                for (int i = 0; i < namesOfDishes.Length; i++)
                {
                    Console.WriteLine(i + 1 + ". " + namesOfDishes[i]);
                }


                int numOfItem = int.Parse(Console.ReadLine());


                string priceCheck = "";

                string dishChosen = namesOfDishes[numOfItem - 1];

                for (int i = 0; i < dishChosen.Length; i++)
                {
                    if (Char.IsDigit(dishChosen[i]))
                        priceCheck += dishChosen[i];
                }


                int price = int.Parse(priceCheck);

                if (price > budget)
                {
                    Console.WriteLine("Your budget is too small for this please either change budget or change dish");
                }
                else
                {
                    Console.WriteLine("Your dish is: " + dishChosen + " your change is: $" + (budget - price));
                    break;
                }
            }
        }
    }
}





/*
 * Because I am not creative enough to figure out a menu I made it so that the user can enter the menu in the beginning if you remove the break from line 96 you can keep on taking orders through the day and even know how much change they would need to give.
 * 
 * 
 * */
